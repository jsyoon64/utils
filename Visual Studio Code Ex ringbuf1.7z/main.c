
#include <stdio.h>
#include <stdint.h>
#include "ringbuf.h"

/* Default size for these tests. */
#define RINGBUF_SIZE 10

int main()
{
    int i,avg;
    uint8_t *head,*tail;

    ringbuf_t rb1 = ringbuf_new(RINGBUF_SIZE); 

    for(i=1;i<50;i++)
    {
        avg=ringbuf_add_getAvg(rb1,i);

        head = (uint8_t*)ringbuf_head(rb1);
        tail = (uint8_t*)ringbuf_tail(rb1);
        
        printf("Insert %d, Average=%d, bytes=%d, head=%d, tail=%d\n", 
        i, avg, ringbuf_bytes_used(rb1), *(head), *(tail));
    }
    return 0;
}