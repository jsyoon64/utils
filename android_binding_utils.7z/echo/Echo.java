package it.cosenonjaviste.databinding.echo;

import org.parceler.Parcel;

import it.cosenonjaviste.databinding.util.BindableString;

@Parcel
public class Echo {
    public BindableString text = new BindableString();
}
