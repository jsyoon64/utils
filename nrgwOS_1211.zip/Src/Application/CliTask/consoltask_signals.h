#ifndef CONSOLTASK_SIGNALS_H
#define CONSOLTASK_SIGNALS_H
/*===============================================================================================
 *
 *   @file consoltask_signals.h
 *
 *   @version v1.0
 *
 *=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Enumerations for substates                                              */

/*****************************************************
                   SIGNAL GROUP

    1. CONSOL TASK  : 0x3000 ~
    2. TIMER        : 0x3000 ~ 0x30FF
    3. EVENT        : 0x3100 ~ 0x31FF
    4. COMMAND      : 0x3200 ~ 0x32FF
    5. RESPONSE     : 0x3300 ~ 0x33FF

*****************************************************/

/* CONSOL COMMANDS. */
typedef enum
{
    CONSOL_DUMMY_TIMER  = 0x3000,
    CONSOL_TIMER_1SEC_F,

    CONSOL_DUMMY_EVENT  = 0x3100,
    CONSOL_RX_MSG_EVT,

    CONSOL_TASK_F       = 0x3200,
    CONSOL_TASK_START_CMD_F,
    CONSOL_RESET_CMD_F,
    CONSOL_TASK_STOP_F,

    CONSOL_MAX_COMMAND = 0x3FFF
} consoltask_signal_type;

/*===============================================================================================*/
#endif  /* CONSOLTASK_SIGNALS_H */
