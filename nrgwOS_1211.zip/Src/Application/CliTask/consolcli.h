/*
  1 tab == 4 spaces!
*/

#ifndef CONSOLCLI_H
#define CONSOLCLI_H

extern char debugMsgDispFlag ;

void vDisplayMessage(  char * ppcMessageToSend );
void consolDebugCLIregister(void);
#endif

