/*===============================================================================================*/
/**
 *   @file consol.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------


*/

/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

#include <stdlib.h>
//#include <conio.h>

/* Scheduler include files. */
#include "FreeRTOS.h"
//#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "task.h"
#include "queue.h"

/* Demo program include files. */
#include "target.h"
#include "comdef.h"
#include "command.h"
#include "consol.h"
#include "consolcli.h"
#include "task_cfg.h"
#include "FreeRTOS_CLI.h"
#if defined(USING_CUBEMX_USB_DRIVER)
#include "usb_device.h"
#include "usbd_cdc_if.h"
#endif
#include "signals.h"


/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/
void vConsolTask( void *pvParameters );

/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/
#define USE_STDIO
    
#define consolINPUT_QUEUE_LENGTH        100
#define COMMAND_INT_MAX_OUTPUT_SIZE     1024//500


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/
static QueueHandle_t xInputQueue;
/* The handle of the queue set to which the queues are added. */
static QueueSetHandle_t xQueueSet;

//static const char * pcTaskStartMsg = "Consol task started.\r\n";

//static char consolBuffer[ consolPRINT_QUEUE_LENGTH ];

/* A buffer into which command outputs can be written is declared here, rather
than in the command console implementation, to allow multiple command consoles
to share the same buffer.  For example, an application may allow access to the
command interpreter by UART and by Ethernet.  Sharing a buffer is done purely
to save RAM.  Note, however, that the command console itself is not re-entrant,
so only one command interpreter interface can be used at any one time.  For that
reason, no attempt at providing mutual exclusion to the cOutputBuffer array is
attempted. */
static char cOutputBuffer[ COMMAND_INT_MAX_OUTPUT_SIZE ];


/*-----------------------------------------------------------*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/

char *consolCLIGetOutputBuffer( void )
{
	memset(&cOutputBuffer[0],0x00,COMMAND_INT_MAX_OUTPUT_SIZE);
	return &cOutputBuffer[0];
}

/*-----------------------------------------------------------*/
void vDisplayMessage(  char * ppcMessageToSend )
{
#ifdef USE_STDIO
        //CDC_Transmit_FS((uint8_t *)ppcMessageToSend, strlen(ppcMessageToSend));
#else
    	/* Stop warnings. */
		( void ) ppcMessageToSend;
#endif
}

void vnDisplayMessage(  char * ppcMessageToSend, uint16_t len )
{
#ifdef USE_STDIO

    #if defined(USING_CUBEMX_USB_DRIVER)
      CDC_Transmit_FS((uint8_t *)ppcMessageToSend, len);
	#endif
#else
    	/* Stop warnings. */
		( void ) ppcMessageToSend;
#endif
}

/*-----------------------------------------------------------*/
void vProcessingInputChar(uint8_t cIn)
{
    char *pcOutputString;
    static uint8_t ucInputIndex = 0;
    /* Dimensions the buffer into which input characters are placed. */
#define cmdMAX_INPUT_SIZE		50
    static char cInputString[ cmdMAX_INPUT_SIZE ];

    //taskENTER_CRITICAL();
    if( (cIn == '\n') || (cIn == '\r'))
    {
        portBASE_TYPE xReturned;
        pcOutputString = consolCLIGetOutputBuffer( );

        /* Pass the received command to the command interpreter.  The
        command interpreter is called repeatedly until it returns pdFALSE
        (indicating there is no more output) as it might generate more than
        one string. */
        if(ucInputIndex !=0)
        {
            do
            {
                /* Get the next output string from the command interpreter. */
                xReturned = FreeRTOS_CLIProcessCommand( cInputString, pcOutputString, COMMAND_INT_MAX_OUTPUT_SIZE );
                vDisplayMessage( pcOutputString );

            } while( xReturned != pdFALSE );
        }
        ucInputIndex = 0;
        memset(cInputString,0x00,cmdMAX_INPUT_SIZE);
    }
    else
    {
        if( ucInputIndex < cmdMAX_INPUT_SIZE )
        {
            cInputString[ ucInputIndex ] = cIn;
            ucInputIndex++;
        }
    }
	//taskEXIT_CRITICAL();
}


/*-----------------------------------------------------------*/
void consolTaskInit(void)
{
	consolDebugCLIregister();
}


/*-----------------------------------------------------------*/
void vConsolTask( void *pvParameters )
{
	uint8_t                 rxMessage ;
	command_type	        cmd;
	QueueSetMemberHandle_t  xQueue;
	QueueSetMemberHandle_t  xActivatedMember;
	uint8_t			        *data = NULL;
    uint16_t                i;

	xQueue = ( QueueSetMemberHandle_t * ) pvParameters;

	consolTaskInit();

	for(;;)
	{
		xActivatedMember =  xQueueSelectFromSet( xQueue, queueSHORT_DELAY );

		/* Which set member was selected?  Receives/takes can use a block time
        of zero as they are guaranteed to pass because xQueueSelectFromSet() would
        not have returned the handle unless something was available. */
        if( xActivatedMember == xCliTaskQueue )
        {
            xQueueReceive( xActivatedMember, &cmd, 0 );
            data = (uint8_t *)cmd.msg;

    		switch(cmd.cmd)
    		{
                case CONSOL_RESET_CMD_F:
                    break;
                    
                case CONSOL_TASK_STOP_F:
                    break;

                case CONSOL_RX_MSG_EVT:
                    vnDisplayMessage((char *)data, cmd.len);
                    
                    for(i=0;i<cmd.len;i++)
                    {
                        portENTER_CRITICAL();
                        xQueueSend(xInputQueue, &data[i], 0);
                        portEXIT_CRITICAL();
                    }
                    break;
                    
    			default:
    				break;
    		}

            if( (cmd.msg != NULL) && (cmd.isconst == FALSE))
    		{
    			cmd_mfree(cmd.msg);
    		}
        }
        else if( xActivatedMember == xInputQueue )
        {
            xQueueReceive( xActivatedMember, &rxMessage, 0 );
            vProcessingInputChar(rxMessage);
        }
        else
        {
            // No cmd rxed, 2000 msec wait timeout
        }
	}
}


/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/
void vStartCONSOLTasks( void )
{

	/*First Create the queue set such that it will be able to hold a message for
	every space in every queue in the set. */
    xQueueSet = xQueueCreateSet( taskCLI_QUEUE_LENGTH + consolINPUT_QUEUE_LENGTH );

	/* Create the queue that we are going to use for the
	prvSendFrontAndBackTest demo. */
	xCliTaskQueue = xQueueCreate( taskCLI_QUEUE_LENGTH, sizeof( command_type ) );
	
	/* Create the queue on which errors will be reported. */
	xInputQueue = xQueueCreate( consolINPUT_QUEUE_LENGTH, sizeof( uint8_t ) );
	
	/* vQueueAddToRegistry() adds the queue to the queue registry, if one is
	in use.  The queue registry is provided as a means for kernel aware
	debuggers to locate queues and has no purpose if a kernel aware debugger
	is not being used.  The call to vQueueAddToRegistry() will be removed
	by the pre-processor if configQUEUE_REGISTRY_SIZE is not defined or is
	defined to be less than 1. */
	//vQueueAddToRegistry( xCliTaskQueue, "CLI_Queue" );
	//vQueueAddToRegistry( xPrintQueue, "CLI_Queue" );
	xQueueAddToSet( xCliTaskQueue, xQueueSet );
	xQueueAddToSet( xInputQueue, xQueueSet );

	/* Spawn the task. */
	//xTaskCreate( vColsolTask, "CLIx", taskCLI_TASK_STACK_SIZE, ( void * ) xCliTaskQueue, taskCLI_TASK_PRIORITY, ( TaskHandle_t * ) NULL );
	xTaskCreate( vConsolTask, "CLIx", taskCLI_TASK_STACK_SIZE, ( void * )xQueueSet, taskCLI_TASK_PRIORITY, ( TaskHandle_t * ) NULL );

}

