/*===============================================================================================*/
/**
 *   @file InEventtask.c
 *
 *   @version v1.0
 */
/*================================================================================================*/


/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */
#include <stdlib.h>


/* Scheduler include files. */
#include "FreeRTOS.h"
//#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "queue.h"
#include "task.h"

/* Application include files. */
#include "command.h"
#include "signals.h"
#include "consol.h"
#include "task_cfg.h"
#include "timers.h"
#include "debugmsgcli.h"
#include "comdef.h"
#include "interface.h"
//#include "tim.h"
#include "comdef.h"
#include "InEventcli.h"

/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/
void vINEVENTTask( void *pvParameters );
    
/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/
#define InEventTIMER_QUEUE_LENGTH 10


/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/

static QueueHandle_t xInEventTimerQueue;

/*-----------------------------------------------------------*/
/* The handle of the queue set to which the queues are added. */
static QueueSetHandle_t xQueueSet;

TimerHandle_t xineventTimer1 = NULL;

/*-----------------------------------------------------------*/

/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/

/*-----------------------------------------------------------*/
void prvInEventTimerCallback( TimerHandle_t pxExpiredTimer )
{
	uint32_t ulTimerID;

    portENTER_CRITICAL();
	ulTimerID = ( uint32_t ) pvTimerGetTimerID( pxExpiredTimer );
	xQueueSend(xInEventTimerQueue,&ulTimerID,0);
    portEXIT_CRITICAL();
}


/*-----------------------------------------------------------*/
static void waitTaskStartSignal(QueueSetMemberHandle_t xQueue)
{
	QueueSetMemberHandle_t	xActivatedMember;
	command_type			cmd;
    uint32_t                timerid;
    
	for(;;)
	{
		xActivatedMember =  xQueueSelectFromSet( xQueue, queueNO_DELAY );

        if( xActivatedMember == xInEventTaskQueue )
        {
            xQueueReceive( xActivatedMember, &cmd, 0 );
        }
        else if( xActivatedMember == xInEventTimerQueue )
        {
            xQueueReceive( xActivatedMember, &timerid, 0 );
            cmd.cmd = (uint16_t)timerid;
            cmd.len = 0;
			cmd.msg = NULL;
        }
		else
		{
			cmd.cmd = 0;
			cmd.msg = NULL;
		}
        
		if(cmd.cmd == INEVENT_TASK_START_CMD_F)
		{
			// start normal processing
			break;
		}
        
		if( (cmd.msg != NULL) && (cmd.isconst == FALSE))
		{
			cmd_mfree(cmd.msg);
		}
        
	}
}

/*-----------------------------------------------------------*/
void ineventtask_init(QueueSetMemberHandle_t  xQueue)
{
	InEventCLIregister();
	waitTaskStartSignal(xQueue);
}

/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/
void vStartInEventTasks( void )
{
	/*First Create the queue set such that it will be able to hold a message for
	every space in every queue in the set. */
	xQueueSet = xQueueCreateSet( taskINEVENT_QUEUE_LENGTH + InEventTIMER_QUEUE_LENGTH );

	xInEventTaskQueue = xQueueCreate( taskINEVENT_QUEUE_LENGTH, sizeof( command_type ) );
	xInEventTimerQueue = xQueueCreate( InEventTIMER_QUEUE_LENGTH, sizeof( uint32_t ) );

	xQueueAddToSet( xInEventTaskQueue, xQueueSet );
	xQueueAddToSet( xInEventTimerQueue, xQueueSet );


	/* Create a one-shot timer for use later on in this test. */
	xineventTimer1 = xTimerCreate(	"",				/* Text name to facilitate debugging.  The kernel does not use this itself. */
								1000,					/* The period for the timer(1 sec). */
								pdFALSE,				/* Don't auto-reload - hence a one shot timer. */
								( void * )INEVENT_TIMER_1SEC_F,	/* The timer identifier. */
								prvInEventTimerCallback );	/* The callback to be called when the timer expires. */

	/* Spawn the task. */
	xTaskCreate( vINEVENTTask, "LED", taskINEVENT_TASK_STACK_SIZE, xQueueSet, taskINEVENT_TASK_PRIORITY, ( TaskHandle_t * ) NULL );

}


/*-----------------------------------------------------------*/
void vINEVENTTask( void *pvParameters )
{
	//QueueHandle_t   xQueue;		// mctask�� queue �ϳ��� ��� �Ҷ�
	QueueSetMemberHandle_t  xQueue;
	QueueSetMemberHandle_t	xActivatedMember;
	command_type	        cmd;
	uint8_t			        *data = NULL;
    uint32_t                timerid;
    uint8_t                 temp;

	xQueue = ( QueueHandle_t * ) pvParameters;

	ineventtask_init(xQueue);
	
	for(;;)
	{
		xActivatedMember =  xQueueSelectFromSet( xQueue, queueSHORT_DELAY );

        if( xActivatedMember == xInEventTaskQueue )
        {
            xQueueReceive( xActivatedMember, &cmd, 0 );
            data = (uint8_t *)cmd.msg;
        }
        else if( xActivatedMember == xInEventTimerQueue )
        {
            xQueueReceive( xActivatedMember, &timerid, 0 );
            cmd.cmd = (uint16_t)timerid;
            cmd.len = 0;
			cmd.msg = NULL;
        }
		else
		{
			cmd.cmd = 0;
			cmd.msg = NULL;
		}
        

		//processing
		switch(cmd.cmd)
		{
			case 0:
				// No cmd rxed, 2000 msec wait timeout
				break;
                
			default:
				break;
		}

		if( (cmd.msg != NULL) && (cmd.isconst == FALSE))
		{
			cmd_mfree(cmd.msg);
		}
	}
}


/*-----------------------------------------------------------*/

